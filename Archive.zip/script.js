//js

const rutExp = /^0*(\d{1,3}(\.?\d{3})*)\-?([\dkK]){6,10}$/gim;
const nombreExp = /^[a-zA-Z]\ üÜ'áéíóúÁÉÍÓÚñÑ\s]*{2,30}$/;
const numeroExp = /^[0-9]{1,3}$/;